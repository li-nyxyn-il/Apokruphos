In the wake of the old [[Yhlgori Empire]]'s dissolution rose the religious institution that empire had created to ingratiate itself to its newfound subjects. The Ecumency has nine great temples located throughout [[Atzchia]] in the cities of the Old Empire. From there, the nine Prelates govern the religious core of the peoples of much of [[Vhinhelm]] and [[Aphlora]]. These city-temples serve as stops along the Great Pilgrimage, along which pilgrims visit holy sites for nine of the Ten Beyonds. 

The Ten Beyonds are an amalgamation of Yhilgori and co-opted Atzchian deities under a unified theology and pantheon the Yhlgori created to help create a sense of unity and ownership amongst the peoples of their new empire upon its founding. They are as follows:

[[The Grymsiere]], the divine ancestor of the Yhlgori and the god of blood and earth,

[[The Phionyx]], ancient Shentzi god of creation, life, fertility, and seasons,

[[Khaska]], the Raven Mother,  Maphlian goddess of wisdom and teaching,

[[Khodos]], the Crow Father, Aphian god of war, famine, and sickness,

[[Jhaspyr]], Vhinhili goddess of the sun, nature, and change, twin to Ilys,

[[Ilys]], Ptormic god of moon, stars, and sky, twin to Jhaspyr,

[[Drake]], Shentzi god of laws and rivers,

[[Baldyro]], Reimenese god of the senses,

[[Demios]], lord of frenzy, Chrysthitian god of storms, god of fear,

[[Mehania]], Yhlgori goddess of darkness and night, the only deity without a prelate or temple along the pilgrimage.

  

Eight of the nine prelates, the exception being the prelate of the Phionyx, are all the heads of a lesser pantheon of their cultural deities as well. These pantheons each have smaller temples in the holy cities of their major deity.**