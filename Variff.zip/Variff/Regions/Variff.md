Continents:

[[Diyk]]