Living Members:

Duke [[Williem Price]] - House Head, Lord of Ptorm (65)
	[[Jhyn Price]], Denounced (42)
		[[Demien Price]] (24)
		[[Jenifyr Price]] (20)
	[[Vanar Price]], Prince of Ptorm (35)
	[[Susanna Ihryl]] (32)
		[[Emanda Price]] (15)
		[[Keit Price]] (14)
		[[Miriam Price]] (10)
		[[Williem Price II]] (8)
	