Lord of [[Seawalt 1]] and Heir to [[Phorva]], eldest descendant of [[Alynare Dane]] and heir to the title of Head of [[House Dane]]

Family:

Parents:
- Mother: [[Alynare Dane]]
- Father: [[Havil Audsen]]
Spouse: [[Ellya Burch]]
Children:
- [[Havil Dane]]
- [[Raven Dane]]
Siblings:
- [[Elyssa Dane]]
- [[Erynalda Dane]]
- [[Sunie Dane]]
- [[Aiden Dane]]
- [[Yniel Dane]]