Current head of [[House Dane]] and she who resurrected the line from long forgotten history
Formerly Known as [[Ythinyx]] Dane

Duchess of [[Phorva]], Subject of [[Grymsol Pynumbros]] [[Robert Field]]

Family and Lineage:
Parents:
- [[Mehania Dane]]: Mother
- Unknown [Nyxian](Nyxians.md) Noble: Father
Spouse: [[Havil Audsen]]
Descendants: 
- [[Halion Dane]]
- [[Elyssa Dane]]
- [[Erynalda Dane]]
- [[Sunie Dane]]
- [[Aiden Dane]]
- [[Yniel Dane]]

