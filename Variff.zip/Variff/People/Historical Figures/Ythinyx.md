[Ythinyx](Dictionary)
