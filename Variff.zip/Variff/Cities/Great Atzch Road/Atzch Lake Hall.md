[[Great Atzch Road]]
[[Temple of Phionyx]]]